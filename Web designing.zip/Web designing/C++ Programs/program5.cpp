#include<iostream>
using namespace std;
int main()
{
    int a,b;
    cout<<"enter a value: ";
    cin>>a>>b;
    cout<<"The value is: "<<((a>b)?a:a);
    return 0;
}
