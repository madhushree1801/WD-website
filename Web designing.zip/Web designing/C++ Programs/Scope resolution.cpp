#include<iostream>
using namespace std;
int a=5;
int main()
{
    int a=1;
    cout<<"local: "<<a<<endl;
    cout<<"Global: "<<::a;
    return 0;
}