#include<iostream>
using namespace std;
class calculator
{
    public:
    int a,b;
    public:
    void sum();
    void diff();
    void mul();
    void div();
    void mod();
};
void calculator :: sum()
{
    cout<<"Enter the values of a and b: ";
    cin>>a>>b;
    cout<<"sum= "<<(a+b)<<endl;
}
void calculator :: diff()
{
    cout<<"Enter the values of a and b: ";
    cin>>a>>b;
    cout<<"difference= "<<(a-b)<<endl;
}
void calculator :: mul()
{
    cout<<"Enter the values of a and b: ";
    cin>>a>>b;
    cout<<"product= "<<(a*b)<<endl;
}
void calculator :: div()
{
    cout<<"Enter the values of a and b: ";
    cin>>a>>b;
    cout<<"Quotient= "<<(a/b)<<endl;
}
void calculator :: mod()
{
    cout<<"Enter the values of a and b: ";
    cin>>a>>b;
    cout<<"Reminder= "<<(a%b)<<endl;
}
int main()
{
    calculator d;
    d.sum();
    d.diff();
    d.mul();
    d.div();
    d.mod();
    return 0;
}