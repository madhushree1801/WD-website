#include<iostream>
using namespace std;
inline float mul(float x, float y)
{
    return(x*y);
}
inline float div(float p ,float q)
{
    return(p/q);
}
int main()
{
    float a=12.34;
    float b=9.82;
    cout<<"Multipication ="<<mul(a,b)<<endl;
    cout<<"Division ="<<div(a,b);
    return 0;
}