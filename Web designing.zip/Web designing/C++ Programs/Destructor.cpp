#include<iostream>
using namespace std;
class marks
{
    public:
    marks()
    {
        cout<<"Inside constructor: "<<endl;
        cout<<"C++ object constructed "<<endl;
    }
~marks()
{
    cout<<"Inside destructor: "<<endl;
    cout<<"C++ object destructed "<<endl;
}
};
int main()
{
    marks(m1);
    marks(m2);
    return 0;
}