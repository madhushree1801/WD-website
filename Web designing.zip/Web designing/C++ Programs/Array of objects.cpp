#include<iostream>
using namespace std;
class MyClass
{
    int a;
    public:
    void set(int x)
    {
        a=x;
    }
    int get()
    {
        return a;
    }
};
int main()
{
    MyClass obj[5];
    int i;
    for(int i=0;i<=5;i++)
    obj[i].set(i);
    for(i=0;i<=5;i++)
    cout<<"["<< i<<"]"<<obj[i].get()<<endl;
    return 0;
}