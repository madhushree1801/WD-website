#include<iostream>
using namespace std;
class largestnum
{
    public:
    int a,b,c,l;
    public:
    void get();
    void largest();
    void display();
};
void largestnum :: get()
{
    cout<<"Enter the values of a,b and c: ";
    cin>>a>>b>>c;
}
void largestnum:: largest()
{
    if(a>b && a>>c)
    {
       l=a;
    }
    else if(b>a && b>c)
    {
       l=b;
    }
    else{
        l=c;
    }
}
void largestnum::display()
{
    cout<<l<<" "<<"is the largest";
}
int main()
{
    largestnum la;
    la.get();
    la.largest();
    la.display();
    return 0;
}