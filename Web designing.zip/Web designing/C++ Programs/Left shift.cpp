#include<iostream>
using namespace std;
int main()
{
    int x,shift;
    cout<<"Enter a number: ";
    cin>>x;
    cout<<"Enter how many times to left shift: ";
    cin>>shift;
    cout<<"Before left shift: "<<x<<endl;
    x=x<shift;
    cout<<"After left shift: "<<x;
    return 0;
}