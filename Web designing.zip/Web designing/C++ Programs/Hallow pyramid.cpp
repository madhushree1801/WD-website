#include<iostream>
using namespace std;
int main()
{
    int r,c,n=5;
    for(r=1;r<=n;r++)
    {
        for(c=n;c>r;c--){
            cout<<" ";
        }
        cout<<" * ";
        cout<<"\n";
    }
    for(c=1;c<(r-1)*2;c++)
    {
           cout<<" ";
    }
    if(r==1){
        cout<<"\n";
    }else {
        cout<<"*\n";
    }
    for(r=n-1;r>=1;r--)
    {
        for(c=n;c>r;c--){
            cout<<" ";
        }
        cout<<"*";
        cout<<"\n";
    }
    for(c=1;c<(r-1)*2;c++){
        cout<<" ";
    }
    if(r==1){
        cout<<"\n";
    }
    else{
        cout<<"*\n";
    }
    return 0;    
}