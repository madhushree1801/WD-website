#include<iostream>
using namespace std;
void main()
{
int a,b;  
cout<<"Enter a, b values:"; 
cin>>a>>b; 
cout<<"a>b"<< a>b; 
cout<<"a>=b"<< a>=b; 
cout<<"a<b"<< a<b; 
cout<<"a<=b"<< a<=b; 
cout<<"a==b"<< a==b; 
cout<<"a!=b"<< a!=b;
}