#include<iostream>
using namespace std;
int main()
{
    int i,j,r=4;
    for(i=0;i<=4;i++)
    {
        for(j=1;j<=i;j++)
        {
          cout<<"*";
        }
        cout<<"\n";
    }
    return 0;
}