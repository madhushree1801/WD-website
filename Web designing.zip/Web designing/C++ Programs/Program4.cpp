#include<iostream>
using namespace std;
int main()
{
    int a;
    cout<<"Enter the value"<<endl;
    cin>>a;
    cout<<"Pre increment: "<<(++a)<<endl;
    cout<<"Post increment: "<<(a++)<<endl;
    cout<<"Pre decrement: "<<(--a)<<endl;
    cout<<"Post decrement: "<<(a--)<<endl;
    cout<<a;
    return 0;
}