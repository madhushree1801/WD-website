#include<iostream>
#include<stdbool.h>
using namespace std;
int main()
{
    bool a,b;
    a=0,b=0;
    cout<<"a && b="<<(a&&b)<<endl;
    a=0;b=1;
    cout<<"a && b="<<(a&&b)<<endl;
    a=0;b=1;
    cout<<"a && b="<<(a&&b)<<endl;
    a=1;b=0;
    cout<<"a && b="<<(a&&b)<<endl;
    a=1;b=1;
    cout<<"a || b="<<(a||b)<<endl;
    a=0;b=0;
    cout<<"a || b="<<(a||b)<<endl;
    a=0;b=1;
    cout<<"a || b="<<(a||b)<<endl;
    a=1;b=0;
    cout<<"a || b="<<(a||b)<<endl;
    a=1;b=1;
    cout<<"a ||| b="<<(a||b)<<endl;
    a=1;
    cout<<"a != b="<<(a||b)<<endl;
    a=0;
    cout<<"a!=b="<<(a||b)<<endl;
    return 0;
}