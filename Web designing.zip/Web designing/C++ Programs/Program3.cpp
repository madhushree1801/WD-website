#include<iostream>
using namespace std;
int main()
{
    int a;
    cout<<"Enter the value"<<endl;
    cin>>a;
    cout<<"Sum of value and 1 using shorthand assignment operator: "<<(a+=1)<<endl;
    cout<<"Difference of value and 1 using shorthand assignment operator: "<<(a-=1)<<endl;
    cout<<"Product of value and 1 using shorthand assignment operator: "<<(a*=1)<<endl;
    cout<<"Quotient of value and 1 using shorthand assignment operator: "<<(a/=1)<<endl;
    cout<<"Reminder of value and 1 using shorthand assignment operator: "<<(a%=1)<<endl;
    return 0;
}