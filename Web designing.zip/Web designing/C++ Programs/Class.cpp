#include<iostream>
using namespace std;
class student
{
    private:int roll;
    char name[30];
    public:
    void get()
    {
        cout<<"Enter the name and roll number: ";
        cin>>name>>roll;
    }
    void put()
    {
        cout<<"Roll number: "<<roll<<endl;
        cout<<"Name:"<<name;
    }
   
};
 int main()
    {
        student s;
        s.get();
        s.put();
       return 0; 
    }