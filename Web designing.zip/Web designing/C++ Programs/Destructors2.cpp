#include<iostream>
using namespace std;
int count = 0;
class alpha
{
    public:
    alpha()
    {
        count++;
        cout<<"\n No. of object created"<<endl;
    }
    ~alpha()
    {
        cout<<"\n No. of object destroyed"<<endl;
        count--;
    }
};
int main()
{
    cout<<"\n\n ENTER MAIN\n";
    alpha A1,A2,A3,A4;
    {
        cout<<"\n\n ENTER BLOCK1\n";
        alpha A5;
    }
    {
        cout<<"\n\n ENTER BLOCK2\n";
        alpha A6;
    }
    cout<<"\n\n RE-ENTER MAIN\n";
    return 0;
}