#include<iostream>
using namespace std;
int main()
{
    int n,c=1,k,i,j;
    cout<<"Enter the number of rows: ";
    cin>>n;
    for(i=0;i<=n;i++){
        for(k=0;k<=n;k++)
        {
            cout<<" ";
        }
        for(j=0;j<=i;j++)
        {
            if(j==0||i==0)
            c=1;
            else
            c=c*(i-j+1)/j;
            cout<<c<<" ";
        }
        cout<<endl;
    }
    return 0;
}