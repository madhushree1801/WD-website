#include<iostream>
using namespace std;
int main()
{
    int x,shift;
    cout<<"Enter a number: ";
    cin>>x;
    cout<<"Enter how many times to right shift: ";
    cin>>shift;
    cout<<"Before right shift: "<<x<<endl;
    x=x>>shift;
    cout<<"After right shift: "<<x;
    return 0;
}