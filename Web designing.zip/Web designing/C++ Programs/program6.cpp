#include<iostream>
#include<stdbool.h>
using namespace std;
int main()
{
    bool a,b;
   cout<<"Enter the value of a and b: ";
   cin>>a>>b;
   cout<<"Bitwise AND for values of a and b:"<<(a&b)<<endl;
   cout<<"Bitwise OR for values of a and b:"<<(a|b)<<endl;
   cout<<"Bitwise Exclusive OR for values of a and b:"<<(a^b)<<endl;
    return 0;
}