#include<iostream>
using namespace std;
class item
{
    int m,n;
    public:
    item(int x,int y)
    {
        m=x;
        n=y;
    }
    void put();
};
void item::put()
{
    cout<<m<<" "<<n<<endl;
}
int main()
{
    item t1(10,20);  //implicit constructor
    item t2=item(20,30);  //explicit constructor
    t1.put();
    t2.put();
    getc;
    return 0;
}