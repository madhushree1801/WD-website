#include<iostream>
using namespace std;
class student
{
    public:int roll;
    char name[30];
    public:
    void get();
    void put();
};
    void student::get()
    {
        cout<<"Enter the name and roll number: ";
        cin>>name>>roll;
    }
    void student::put()
    {
        cout<<"Roll number: "<<roll<<endl;
        cout<<"Name:"<<name;
    }
   

 int main()
    {
        student s;
        s.get();
        s.put();
       return 0; 
    }